# CM_Beat_Prisoners
 A Rimworld mod that gives you a new way to reduce the resistance of your prisoners
